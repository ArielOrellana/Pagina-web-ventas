<p class="alert alert-info">
	desde esta seccion podremos, crear , editar y eliminar las categorias
</p>