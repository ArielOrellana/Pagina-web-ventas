@section('title','Zontal+Admin')
@include('layouts.head')

@include('layouts.nav')

@include('layouts.fin')